package com.dareum.wlgid.dareum_app.Cont;

/**
 * Created by wlgid on 2017-06-15.
 */

public class SpacecraftMy {
    String imei, gominca, sgominca, title, contgo, image, comgo, likego, w_com, m_com, a_com, b_img, time;
    int num;

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getGominca() {
        return gominca;
    }

    public void setGominca(String gominca) {
        this.gominca = gominca;
    }

    public String getSgominca() {
        return sgominca;
    }

    public void setSgominca(String sgominca) {
        this.sgominca = sgominca;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContgo() {
        return contgo;
    }

    public void setContgo(String contgo) {
        this.contgo = contgo;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getComgo() {
        return comgo;
    }

    public void setComgo(String comgo) {
        this.comgo = comgo;
    }

    public String getLikego() {
        return likego;
    }

    public void setLikego(String likego) {
        this.likego = likego;
    }

    public String getW_com() {
        return w_com;
    }

    public void setW_com(String w_com) {
        this.w_com = w_com;
    }

    public String getM_com() {
        return m_com;
    }

    public void setM_com(String m_com) {
        this.m_com = m_com;
    }

    public String getA_com() {
        return a_com;
    }

    public void setA_com(String a_com) {
        this.a_com = a_com;
    }

    public String getB_img() {
        return b_img;
    }

    public void setB_img(String b_img) {
        this.b_img = b_img;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
}
