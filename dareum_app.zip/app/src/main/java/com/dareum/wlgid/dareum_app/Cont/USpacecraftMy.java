package com.dareum.wlgid.dareum_app.Cont;

/**
 * Created by wlgid on 2017-10-28.
 */

public class USpacecraftMy {
    String gender, love, imei;

    public String getGender() { return gender; }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getLove() {
        return love;
    }

    public void setLove(String love) {
        this.love = love;}

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }
}
