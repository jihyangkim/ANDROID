package com.dareum.wlgid.dareum_app.Tutorial;

/**
 * Created by MINTIE on 2017-05-03.
 */

public class Config {
    public static String FLAG="2";
}
